﻿namespace HospitalSecondSolution
{
    public class Patient
    {
        private string name;
        
        public Patient(string name)
        {
            this.Name = name;
        }

        public string Name { get; set; }
    }
}
