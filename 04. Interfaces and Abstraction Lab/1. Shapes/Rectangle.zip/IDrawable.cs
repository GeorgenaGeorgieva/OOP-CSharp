﻿namespace Shapes
{
    public interface IDrawable
    {
        string Draw();
    }
}
