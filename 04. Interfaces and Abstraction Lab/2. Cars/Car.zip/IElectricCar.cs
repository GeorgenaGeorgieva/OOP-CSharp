﻿namespace Cars
{
    public interface IElectricCar
    {
        int Batteries { get; }
    }
}
