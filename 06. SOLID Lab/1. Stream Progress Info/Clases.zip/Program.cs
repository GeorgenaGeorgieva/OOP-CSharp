﻿namespace StreamProgress
{
    using System;

    public class Program
    {
        static void Main()
        {   
        }
    }
}
