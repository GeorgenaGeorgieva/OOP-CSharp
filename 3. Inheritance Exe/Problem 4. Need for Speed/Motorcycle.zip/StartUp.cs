﻿namespace NeedForSpeed
{
    using System;
    using Car;
    using Motorcycle;
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Console.WriteLine();
        }
    }
}
