﻿namespace VehiclesExtension.Enum
{
    public enum StateAirConditioner
    {
        Off,
        On
    }
}
