﻿namespace WildFarm.Interfaces
{
    public interface IFeline
    {
        string Breed { get; }
    }
}
