﻿namespace WildFarm.Clases.Food
{
    public class Seeds : Food
    {
        public Seeds(int quantity)
            : base(quantity)
        {
        }
    }
}
