﻿namespace Shapes.Interfaces
{
    public interface IRectangle
    {
        double Height { get; }
        double Width { get; }
    }
}
