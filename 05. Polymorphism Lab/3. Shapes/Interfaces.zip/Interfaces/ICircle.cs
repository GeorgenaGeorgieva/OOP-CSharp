﻿namespace Shapes.Interfaces
{
    public interface ICircle
    {
        double Radius { get; }
    }
}
