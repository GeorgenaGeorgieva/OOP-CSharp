﻿namespace StudentSystemCatalog.Data
{
    public interface IDataReader
    {
        public string Read();
    }
}
