﻿namespace StudentSystemCatalog.Data
{
    public interface IDataWriter
    {
        public void Write(object obj);
    }
}
