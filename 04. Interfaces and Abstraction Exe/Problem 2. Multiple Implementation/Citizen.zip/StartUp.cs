﻿namespace PersonInfo
{
	using System;

	public class StartUp
    {
        public static void Main(string[] args)
        {
			try
			{
				string name = Console.ReadLine();
				int age = int.Parse(Console.ReadLine());
				string id = Console.ReadLine();
				string birthdate = Console.ReadLine();

				var citizen = new Citizen(name, age, id, birthdate);
				Console.WriteLine(citizen);
			}
			catch (ArgumentException exception)
			{
				Console.WriteLine(exception.Message);	
			}
        }
    }
}
