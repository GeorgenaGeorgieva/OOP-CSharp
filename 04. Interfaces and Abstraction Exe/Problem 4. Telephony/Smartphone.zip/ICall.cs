﻿using System.Collections.Generic;

namespace Telephony
{
    public interface ICall
    {
        string Call(string[] phoneNumbers);
    }
}
