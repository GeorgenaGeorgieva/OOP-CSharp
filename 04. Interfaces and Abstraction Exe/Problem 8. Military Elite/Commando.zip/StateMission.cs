﻿namespace MilitaryElite
{
    public enum StateMission
    {
        inProgress,
        finished
    }
}
