﻿namespace FoodShortage.Interfaces
{
    using System;

    public interface IBirthdate
    {
        DateTime Birthdate { get; }
    }
}
