﻿namespace FoodShortage.Interfaces
{
    public interface IName
    {
        string Name { get; }
    }
}
