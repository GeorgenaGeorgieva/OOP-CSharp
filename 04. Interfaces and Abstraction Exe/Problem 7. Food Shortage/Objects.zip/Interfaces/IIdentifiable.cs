﻿namespace FoodShortage.Interfaces
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
