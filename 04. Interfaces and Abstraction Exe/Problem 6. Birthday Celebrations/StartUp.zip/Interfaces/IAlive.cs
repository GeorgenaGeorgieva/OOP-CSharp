﻿namespace BirthdayCelebrations.Interfaces
{
    public interface IAlive
    {
        string Name { get; }
        string Birthdate { get; }
    }
}
