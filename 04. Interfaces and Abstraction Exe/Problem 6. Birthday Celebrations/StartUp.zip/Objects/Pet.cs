﻿namespace BirthdayCelebrations.Objects
{
    public class Pet : Creature
    {
        public Pet(string name, string birthdate)
            :base(name, birthdate)
        {
        }
    }
}
